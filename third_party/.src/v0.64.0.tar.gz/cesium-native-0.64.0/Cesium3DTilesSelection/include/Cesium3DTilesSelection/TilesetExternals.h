#pragma once

#include <Cesium3DTilesSelection/Library.h>
#include <Cesium3DTilesSelection/TileOcclusionRendererProxy.h>
#include <Cesium3DTilesSelection/TilesetSharedAssetSystem.h>
#include <Cesium3DTilesSelection/spdlog-cesium.h>
#include <CesiumAsync/AsyncSystem.h>

#include <memory>

namespace CesiumAsync {
class IAssetAccessor;
class ITaskProcessor;
} // namespace CesiumAsync

namespace CesiumUtility {
class CreditSystem;
}

namespace Cesium3DTilesSelection {

class IPrepareRendererResources;
class GltfModifier;

/**
 * @brief External interfaces used by a @ref Tileset.
 *
 * Not supposed to be used by clients.
 */
class CESIUM3DTILESSELECTION_API TilesetExternals final {
public:
  /**
   * @brief An external @ref CesiumAsync::IAssetAccessor.
   */
  std::shared_ptr<CesiumAsync::IAssetAccessor> pAssetAccessor;

  /**
   * @brief An external @ref IPrepareRendererResources.
   */
  std::shared_ptr<IPrepareRendererResources> pPrepareRendererResources;

  /**
   * @brief The async system to use to do work in threads.
   *
   * The tileset will automatically call
   * @ref CesiumAsync::AsyncSystem::dispatchMainThreadTasks from
   * @ref Tileset::updateView.
   */
  CesiumAsync::AsyncSystem asyncSystem;

  /**
   * @brief An external @ref CesiumUtility::CreditSystem that can be used to
   * manage credit strings and periodically query which credits to show and and
   * which to remove from the screen.
   */
  std::shared_ptr<CesiumUtility::CreditSystem> pCreditSystem;

  /**
   * @brief A spdlog logger that will receive log messages.
   *
   * If not specified, defaults to `spdlog::default_logger()`.
   */
  std::shared_ptr<spdlog::logger> pLogger = spdlog::default_logger();

  /**
   * @brief A pool of renderer proxies to determine the occlusion state of
   * tile bounding volumes.
   *
   * If not specified, the traversal will not attempt to leverage occlusion
   * information.
   */
  std::shared_ptr<TileOcclusionRendererProxyPool> pTileOcclusionProxyPool =
      nullptr;

  /**
   * @brief The shared asset system used to facilitate sharing of common assets,
   * such as images, between and within tilesets.
   */
  CesiumUtility::IntrusivePointer<TilesetSharedAssetSystem> pSharedAssetSystem =
      TilesetSharedAssetSystem::getDefault();

  /**
   * Optional user-controlled tile loading post-processing stage that can modify
   * the glTF meshes (e.g., split or merge them).
   *
   * @see Cesium3DTilesSelection::GltfModifier
   */
  std::shared_ptr<GltfModifier> pGltfModifier = {};
};

} // namespace Cesium3DTilesSelection
